class Request < ApplicationRecord
	
end
