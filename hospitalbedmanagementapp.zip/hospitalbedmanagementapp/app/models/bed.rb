class Bed < ApplicationRecord
end
