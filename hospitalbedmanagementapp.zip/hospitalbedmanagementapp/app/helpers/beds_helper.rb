module BedsHelper
end
