require 'test_helper'

class BedTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
